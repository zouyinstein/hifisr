Third-party libraries
=====================

This folder is excluded from the licensing of the rest of the code. The
corresponding licenses of the third-party libraries applies.
