This is a collection of miscellaneous code used by
[meryl](https://github.com/marbl/meryl),
[canu](https://github.com/marbl/canu),
[sequence](https://github.com/marbl/sequence)
and others.

Although a Makefile is provided, it is expected this code will be included as
a submodule in your project and compiled directly.
